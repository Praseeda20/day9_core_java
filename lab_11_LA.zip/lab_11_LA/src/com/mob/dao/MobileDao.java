package com.mob.dao;

import com.mob.bean.PurchaseDetailsBean;
import com.mob.exception.MobileException;

public interface MobileDao {
	public int addPurchaseDetails(PurchaseDetailsBean purchase) throws MobileException;
}
