package com.mob.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mob.bean.PurchaseDetailsBean;
import com.mob.exception.MobileException;
import com.mob.util.DBConnection;

public class MobileDaoImpl implements MobileDao {
	Logger logger=Logger.getLogger(MobileDaoImpl.class);
	public MobileDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
		}
		PurchaseDetailsBean purchase = new PurchaseDetailsBean();



	private int generatePurchaseId() throws MobileException {
		logger.debug("Entered generatePurchaseId of Dao");
		int id = 0;
		Connection con = null;
		String qry = "Select purchaseid_seq.nextval from dual";
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id = rst.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addPurchaseDetails(PurchaseDetailsBean purchase) throws MobileException {
		logger.debug("Entered addPurchaseDetails of Dao");
		Connection con = null;
		int id = 0;
		int queryResult = 0;
		PreparedStatement pstmt = null;
		String cmd = "Insert into purchasedetails(purchaseid, cname, mailid, phoneno, purchasedate, mobileid)"
				+ "values(?, ?, ?, ?, sysdate, ?)";
		try {
			con = DBConnection.getConnection();
			logger.info("Connection made to Database");
			id = generatePurchaseId();
			pstmt = con.prepareStatement(cmd);

			pstmt.setString(1, String.valueOf(id));
			pstmt.setString(2, purchase.getcName());
			pstmt.setString(3, purchase.getMailId());
			pstmt.setLong(4, purchase.getPhNumber());
			pstmt.setString(5, purchase.getMobileId());

			queryResult = pstmt.executeUpdate();
			if (queryResult == 0) {
				System.out.println("Insertion failed ");
				logger.error("Insertion failed");
				throw new MobileException("Inserting purchase details failed ");
			} 
			else {
				System.out.println("Purchase details added successfully:");
				
				String id1=null;
				id1=updateMobiles(purchase.getMobileId());
			}
		} 
		catch (SQLException e) {
			logger.error("unable to insert");
			throw new MobileException("Unable to insert");
		} 
		return id;
	}
	
	public String updateMobiles(String mobileId){
		Connection con = null;
		int id = 0;
		int queryResult = 0;
		PreparedStatement pstmt = null;
		String cmd = "update mobiles set quantity=quantity-1 where mobileid=?";
		try {
			con=DBConnection.getConnection();
			pstmt = con.prepareStatement(cmd);

			pstmt.setString(1, mobileId);
			queryResult = pstmt.executeUpdate();
			if(queryResult==0){
				throw new MobileException("Cannot update Details");
			}
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mobileId;
	}

}
