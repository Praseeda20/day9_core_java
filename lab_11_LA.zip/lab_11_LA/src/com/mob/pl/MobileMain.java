package com.mob.pl;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.mob.bean.PurchaseDetailsBean;
import com.mob.dao.MobileDaoImpl;
import com.mob.exception.MobileException;
import com.mob.service.MobileService;
import com.mob.service.MobileServiceImpl;

public class MobileMain {
	
	public static void main(String[] args) {
		Logger logger=Logger.getLogger(MobileDaoImpl.class);
	PurchaseDetailsBean purchase= new PurchaseDetailsBean();
	Scanner sc= new Scanner(System.in);
	MobileService service= new MobileServiceImpl();
	int num=0;
	while(num<3){
	System.out.println("\n***************************"
			+ "\n1.Add Purchase Details\n2.Update Details By Id\n3.Exit\n***************************"
			+ "\nEnter your choice: ");
	num=sc.nextInt();
	
	int id=0;
	switch(num){
	case 1: try {
			System.out.println("Enter the Customer Name: ");
				    String cname= sc.next();
				    System.out.println("Enter the Mail ID: ");
				    String mailId= sc.next();
				    System.out.println("Enter the Phone Number: ");
				    long phNumber= sc.nextLong();
				    System.out.println("Enter the mobile ID: ");
				    String mobileId= sc.next();
				    
				    purchase.setcName(cname);
				    purchase.setMailId(mailId);
				    purchase.setPhNumber(phNumber);
				    purchase.setMobileId(mobileId);
				    
				    
				    id = service.addPurchaseDetails(purchase);
				    logger.info("Purchase details added");
		} catch (MobileException e) {
			logger.error("Can not add the purchase Details");
			e.printStackTrace();
		}
	break;
	case 2: 
		break;
	case 3: System.exit(0);
	break;
	default:System.out.println("Invalid Input");
		    
		    
		  
	}
	}
	sc.close();
	}
}
