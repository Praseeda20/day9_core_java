package com.edms.service;

import com.edms.bean.EmployeeBean;
import com.edms.exceptions.EmployeeException;

public interface EmployeeService {
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public EmployeeBean viewEmployeeById(int id) throws EmployeeException;	

}
