package com.edms.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.edms.bean.EmployeeBean;
import com.edms.dao.EmployeeDao;
import com.edms.dao.EmployeeDaoImpl;
import com.edms.exceptions.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao employeeDao=new EmployeeDaoImpl();
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id = employeeDao.addEmployee(bean);
		return id;
	}

	@Override
	public EmployeeBean viewEmployeeById(int id) throws EmployeeException {
		EmployeeBean  emp = employeeDao.viewEmployeeById(id) ;
		return emp;
	}
	
	public boolean isValidName(String empName){
		Pattern namePattern=Pattern.compile("^[A-Z]{1}[a-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(empName);
		return nameMatcher.matches();
	}
	
	public boolean isValidContactNumber(long empNumber){
		Pattern numberPattern=Pattern.compile("[7-8-9]{1}[0-9]{9}");
		Matcher numberMatcher=numberPattern.matcher(String.valueOf(empNumber));
		return numberMatcher.matches();
	}
	
	public boolean isValidEmpId(long empId){
		Pattern empIdPattern=Pattern.compile("[1-9][0-9]{3,}");
		Matcher empIdMatcher=empIdPattern.matcher(String.valueOf(empId));
		return empIdMatcher.matches();
	}
	
	public boolean isValidEmail(String empMail){
		Pattern mailPattern=Pattern.compile("[(a-z0-9\\._)]+@[(a-z)]+\\.[(a-z)]+");
		Matcher mailMatcher=mailPattern.matcher(empMail);
		return mailMatcher.matches();
	}
	
	

}
