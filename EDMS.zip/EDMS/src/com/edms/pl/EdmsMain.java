package com.edms.pl;

import java.util.Scanner;

import com.edms.bean.EmployeeBean;
import com.edms.exceptions.EmployeeException;
import com.edms.service.EmployeeService;
import com.edms.service.EmployeeServiceImpl;


public class EdmsMain {
	static EmployeeBean bean=new EmployeeBean();
	static EmployeeService service=new EmployeeServiceImpl();
	static EmployeeServiceImpl serviceImpl=new EmployeeServiceImpl();
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
	
		int num=0;
		while(num<3){
		System.out.println("\n***************************"
				+ "\n1.Add Employee\n2.View Employee By Id\n3.Exit\n***************************"
				+ "\nEnter your choice: ");
		num=sc.nextInt();
		
		int id=0;
		
		
		switch(num)
		
		{
			case 1:	try{
					addEmployeeDetails();
							}			
		
					catch (Exception e1) {
						System.out.println("Unable to insert"+e1);
					}
					break;
			case 2: System.out.println("Enter employee id: ");
					id=sc.nextInt();
					try {
						if (serviceImpl.isValidEmpId(id)) {
							bean = 	service.viewEmployeeById(id);
							if(bean !=null)
							{
							System.out.println(bean);
							}
							else
							{
								System.out.println("No such ID found");
							}
						}
						else
							System.out.println("Invalid Employee ID");
					} catch (EmployeeException e) {
						System.out.println(e.getMessage());	}
					break;
			case 3: System.exit(0);
					break;
			default:System.out.println("Invalid choice");
		}
		}	
		sc.close();
	}

	public static EmployeeBean addEmployeeDetails()
	{
		System.out.println("Enter employee first name: ");
		String firstName=sc.next();
		if (serviceImpl.isValidName(firstName)) {
			bean.setEmpFirstName(firstName);
			System.out.println("Enter employee last name: ");
			String lastName=sc.next();
			if (serviceImpl.isValidName(lastName)){
				bean.setEmpLastName(lastName);
				System.out.println("Enter employee Contact Number: ");
				long contactNumber=sc.nextLong();
				if (serviceImpl.isValidContactNumber(contactNumber)){
					bean.setEmpContactNumber(contactNumber);
					System.out.println("Enter employee Email ID: ");
					String mailId=sc.next();
					if (serviceImpl.isValidEmail(mailId)) {
						bean.setEmpEmail(mailId);
						try {
							service.addEmployee(bean);
						} catch (EmployeeException e) {
							e.printStackTrace();
						}
					}
					else
						System.out.println("Invalid Mail ID");
				}
				else
					System.out.println("Invalid Contact Number..must contain 10 digits");
			}
			else
				System.out.println("Last Name should start with capital & contain minimum 4 chars");
		}
		else
			System.out.println("First Name should start with capital & contain minimum 4 chars");
		return bean;

	}
}
