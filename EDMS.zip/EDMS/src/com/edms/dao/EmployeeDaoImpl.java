package com.edms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.edms.bean.EmployeeBean;
import com.edms.exceptions.EmployeeException;
import com.edms.util.DBConnection;
import com.edms.dao.EmployeeDaoImpl;

public class EmployeeDaoImpl implements EmployeeDao {
	Logger logger = Logger.getLogger(EmployeeDaoImpl.class);

	public EmployeeDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");

	}

	EmployeeBean emp = null;

	private int generateEmployeeId() {
		int id = 0;
		Connection con = null;
		String qry = "Select emp_id_sequence.nextval from dual";
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id = rst.getInt(1);
		} catch (SQLException | EmployeeException e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con = null;
		int id = 0;
		int queryResult = 0;
		PreparedStatement pstmt = null;
		String cmd = "Insert into employee_tbl (emp_id, emp_firstname, emp_lastname,"
				+ " emp_contactnumber, emp_doj, emp_email) "
				+ "values(?,?,?,?,sysdate,?)";
		try {
			con = DBConnection.getConnection();
			id = generateEmployeeId();
			pstmt = con.prepareStatement(cmd);

			pstmt.setString(1, String.valueOf(id));
			pstmt.setString(2, bean.getEmpFirstName());
			pstmt.setString(3, bean.getEmpLastName());
			pstmt.setLong(4, bean.getEmpContactNumber());
			pstmt.setString(5, bean.getEmpEmail());

			queryResult = pstmt.executeUpdate();
			if (queryResult == 0) {
				logger.error("Insertion failed ");
				throw new EmployeeException(
						"Inserting employee details failed ");
			} else {
				logger.info("Employee details added successfully:");
				return id;
			}
		} catch (SQLException e) {
			throw new EmployeeException("Unable to insert");
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new EmployeeException("Error in closing db connection");

			}
		}
	}

	@Override
	public EmployeeBean viewEmployeeById(int id) throws EmployeeException {
		emp = new EmployeeBean();
		Connection con = null;
		PreparedStatement prepstmt = null;
		ResultSet rst = null;
		try {

			String cmd = "select emp_id, emp_firstname, emp_lastname,"
					+ "emp_contactnumber, emp_doj, emp_email"
					+ " from employee_tbl where emp_id=(?)";
			con = DBConnection.getConnection();
			prepstmt = con.prepareStatement(cmd);
			prepstmt.setInt(1, id);
			rst = prepstmt.executeQuery();
			if (rst.next()) {
				emp.setEmpId((rst.getString(1).toString()));
				emp.setEmpFirstName(rst.getString(2));
				emp.setEmpLastName(rst.getString(3));
				emp.setEmpContactNumber(rst.getLong(4));
				emp.setEmpDoj(rst.getDate(5));
				emp.setEmpEmail(rst.getString(6));
				logger.info("Record Found Successfully");
				
			}
			
		else {
			logger.error("record not found");	
			throw new EmployeeException("Record not found");
				
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
		} finally {
			try {
				rst.close();
				prepstmt.close();
				con.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new EmployeeException("Error in closing db connection");

			}
		}
		return emp;

	}

}
