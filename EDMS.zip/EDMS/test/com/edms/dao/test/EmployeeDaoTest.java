package com.edms.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.edms.bean.EmployeeBean;
import com.edms.dao.EmployeeDaoImpl;
import com.edms.exceptions.EmployeeException;

public class EmployeeDaoTest {
	static EmployeeDaoImpl employeeDao;
	static EmployeeBean bean;
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		employeeDao = new EmployeeDaoImpl();
		bean = new EmployeeBean();
	}
	
	@Test
	public void testAddEmployeeDetails() throws EmployeeException {
		assertNotNull(employeeDao.addEmployee(bean));
	}
	@Ignore
	@Test
	public void testAddEmployeeDetails1() throws EmployeeException {
		
		bean.setEmpFirstName("Kanika");
		bean.setEmpLastName("Setia");
		bean.setEmpContactNumber(9876543452l);
		bean.setEmpEmail("ks6@gmail.com");
		employeeDao.addEmployee(bean);
		assertTrue("Data not Inserted", employeeDao.addEmployee(bean) > 1000);
	}
	
	@Ignore
	@Test
	public void testViewEmployee() throws EmployeeException {
		assertNotNull(employeeDao.viewEmployeeById(1007));
	}
	
	@Ignore
	@Test
	public void testViewEmployee1() throws EmployeeException {
		assertNotNull(employeeDao.viewEmployeeById(1010));
	}
	
	@Test
	public void testViewEmployee2() throws EmployeeException {
		assertEquals("Not Matched", "Himanshu", employeeDao.viewEmployeeById(1007).getEmpFirstName());
	}
}
