package com.edms.dao.test;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.edms.dao.EmployeeDaoImpl;
import com.edms.exceptions.EmployeeException;
import com.edms.util.DBConnection;

public class DBConnectionTest {
	static EmployeeDaoImpl employeeDao;
	static Connection dbCon;

	@BeforeClass
	public static void initialise() {
		employeeDao = new EmployeeDaoImpl();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws DonorException
	 **/
	@Test
	public void test() throws EmployeeException {
		Connection dbCon = DBConnection.getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		employeeDao = null;
		dbCon = null;
	}
}
